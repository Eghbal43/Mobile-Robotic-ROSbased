#!/usr/bin/env python3


import rospy, math  #importar los archivos de cabecera rospy para python y math porque usamos seno cos pi
from geometry_msgs.msg import Twist, Pose2D #para publicar las velocidades y tracking errors usando the Pose2D message type agragado desde rostopic list para topic /cmd_vel
from nav_msgs.msg import Odometry  # agregado para el topic /odom
from tf.transformations import euler_from_quaternion, quaternion_from_euler #usado para la conversion de quaternios a angulos de euler
from math import sin, cos, pi

import sys, select, os
if os.name == 'nt':
  import msvcrt
else:
  import tty, termios

# Initialize the position of the robot
x = 0
y = 0
yaw = 0
l = 0.1

vel_msg = Twist()
error_msg = Pose2D()
t = 0.0
t0 = 0.0
V_max = 0.22
W_max = 2.84
T = 100.0
k = 0.15
ex = 0.0
ey = 0.0
V = 0.0
W = 0.0

# PID parameters for yaw control
Kp_yaw = 1.0
Ki_yaw = 0.002
Kd_yaw = 0.00001
integral_yaw = 0.0
previous_yaw_error = 0.0

def getKey():
    if os.name == 'nt':
        return msvcrt.getch()
    tty.setraw(sys.stdin.fileno())
    rlist, _, _ = select.select([sys.stdin], [], [], 0.1)
    if rlist:
        key = sys.stdin.read(1)
    else:
        key = ''
    termios.tcsetattr(sys.stdin, termios.TCSADRAIN, settings)
    return key

def odomCallback(msg):
    global x; global y; global yaw
    x = msg.pose.pose.position.x
    y = msg.pose.pose.position.y

    quater = msg.pose.pose.orientation
    quater_list = [quater.x, quater.y, quater.z, quater.w]
    (roll, pitch, yaw) = euler_from_quaternion(quater_list)

def velocity_controller():
    global ex, ey, V, W, Xd, Yd, integral_yaw, previous_yaw_error

    # Trajectory desired: Lemniscate
    a = 1
    b = 0.5
    X0 = 0
    Y0 = 0
    w = 2 * pi / T

    # Desired position in the plane
    Xd = X0 + a * sin(w * t)
    Yd = Y0 + b * sin(2 * w * t)

    # Derivation
    Xdp = a * w * cos(w * t)
    Ydp = 2 * b * w * cos(2 * w * t)

    p_x = x + l * cos(yaw)
    p_y = y + l * sin(yaw)

    ex = p_x - Xd
    ey = p_y - Yd

    # Desired yaw angle
    desired_yaw = math.atan2(Yd - y, Xd - x)
    yaw_error = desired_yaw - yaw

    # PID control for yaw
    integral_yaw += yaw_error
    derivative_yaw = yaw_error - previous_yaw_error

    W = Kp_yaw * yaw_error + Ki_yaw * integral_yaw + Kd_yaw * derivative_yaw
    previous_yaw_error = yaw_error

    # Linear velocity control (keeping it simple and constant for now)
    V = 0.1  # constant linear velocity

    
   
    # Publish velocities
    vel_msg.linear.x = V
    vel_msg.angular.z = W

def main_function():
	rospy.init_node('diff_robot_controller', anonymous=False) #Inicializar el nodo
	rate = rospy.Rate(100) #frecuencia del nodo (Hz)
	counter = 0
	
	vel_pub = rospy.Publisher('/cmd_vel', Twist, queue_size=10) #para publicar en el topico 
	rospy.Subscriber('/odom',Odometry, odomCallback) #para suscribirse en el topico 

	error_pub = rospy.Publisher('/tracking_errors', Pose2D, queue_size=10);

	file_obj = open("data_py.txt","w+") #si solo le damos el nombre
	#el programa se crea en  "/home/user/"
	
	#campos puestos en zero por utilizar un robot tipo diferencial
	vel_msg.linear.y = vel_msg.linear.z = vel_msg.angular.x = vel_msg.angular.y = 0;
	
	error_msg.theta = 0 

	
	print("To finish this node and to stop the robot, please press 'ctrl+C'\n")
	rospy.logwarn("To start the movement, the simulation must be running\n\n")
	
	global t, t0 #t y t0 son globales para ser usadas en el controlador de la velocidad 
	t0 = rospy.Time.now().to_sec()
	
	while(1):
		t = rospy.Time.now().to_sec()-t0 #calcular el tiempo del controlador    
		velocity_controller() #calcular las señales de  control 
		
		vel_msg.linear.x = V; vel_msg.angular.z = W
		vel_pub.publish(vel_msg); #Publicar las señales de control
	
		error_msg.x = ex; error_msg.y = ey; #asignal el error en tranckin
		error_pub.publish(error_msg); #publicar el tracking error

		#excribir en el documento creado
		text_t = "{:.3f}".format(t) 
		text_Xd = "{:.3f}".format(Xd); text_Yd = "{:.3f}".format(Yd)
		text_x = "{:.3f}".format(x); text_y = "{:.3f}".format(y)
		text_V = "{:.3f}".format(V); text_W = "{:.3f}".format(W)
		text_line = text_t+"\t"+text_Xd+"\t"+text_Yd+"\t"+text_x+"\t"+text_y+"\t"+text_V+"\t"+text_W+"\n"
		#print (text_line)

		file_obj.write(text_line)
		
		if counter == 25:
			rospy.loginfo("t: %.2f\tex: %.3f\tey: %.3f\tV: %.3f\tW: %.2f\n", t,ex,ey,V,W) #impirmir algunas variables
			counter = 0 #Resetear el contador
		else:
			counter += 1
		
		key = getKey()
		if(key == 'q' or key == '\x03'): #\x03 is ctrl+C

			break
		
		rate.sleep() 
	
	file_obj.close()
#deter el robot
	vel_msg.linear.x = 0.0; vel_msg.angular.z = 0.0
	vel_pub.publish(vel_msg)
	
	print("Robot stops, but simulation keeps running\n")



if __name__ == '__main__':
    if os.name != 'nt':
        settings = termios.tcgetattr(sys.stdin)
 
    try:
        main_function() #Execute the function
    except rospy.ROSInterruptException:
        pass




